
//here is a sample code for my project. the system will be running approximately like this.
import java.util.ArrayList;
import java.util.List;
//this code defines three classes: OnlineAuctionSystem, Item, User, and Bid. The OnlineAuctionSystem class is the main class that contains the lists of items, users, and bids. The Item class represents an item that can be auctioned, and the User class represents a user who can bid on items. The Bid class represents a bid made by a user on an item.
public class OnlineAuctionSystem {
    private List<Item> items;
    private List<User> users;
    private List<Bid> bids;

    public OnlineAuctionSystem() {
        items = new ArrayList<>();
        users = new ArrayList<>();
        bids = new ArrayList<>();
    }

    public void addItem(Item item) {
        items.add(item);
    }

    public void addUser(User user) {
        users.add(user);
    }

    public void addBid(Bid bid) {
        bids.add(bid);
    }

    public List<Item> getItems() {
        return items;
    }

    public List<User> getUsers() {
        return users;
    }

    public List<Bid> getBids() {
        return bids;
    }
}

class Item {
    private String name;
    private String description;
    private double price;

    public Item(String name, String description, double price) {
        this.name = name;
        this.description = description;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public double getPrice() {
        return price;
    }
}

class User {
    private String name;
    private String email;

    public User(String name, String email) {
        this.name = name;
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }
}

class Bid {
    private User user;
    private Item item;
    private double amount;

    public Bid(User user, Item item, double amount) {
        this.user = user;
        this.item = item;
        this.amount = amount;
    }

    public User getUser() {
        return user;
    }

    public Item getItem() {
        return item;
    }

    public double getAmount() {
        return amount;
    }
}